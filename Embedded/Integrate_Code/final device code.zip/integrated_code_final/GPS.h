#include <TinyGPS++.h>

BluetoothSerial SerialBT;
TinyGPSPlus gps;
// setup 에 사용핀 등을 기재하기위한 양식 
//void setup()
//{
//  Serial.begin(115200);
//  Serial2.begin(9600, SERIAL_8N1, 2, 23); // RX, TX
//  SerialBT.begin("ESP32_GPS");
//}


static float get_gps_info_lat(){
  float lat;
  if (gps.location.isValid())
    {
      lat = gps.location.lat()
    }
  else{
      serial.print(F("INVALID"));
    }

  return lat;
}

static float get_gps_info_lng(){
  float lat;
  if (gps.location.isValid())
    {
      lat = gps.location.lng()
    }
  else{
      serial.print(F("INVALID"));
    }


   return lng;
}
