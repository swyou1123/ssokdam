int gas_check(){
  return analogRead(Gas_Pin);
}
