#include <Ethernet.h>

#include <WiFi.h>
#include <HTTPClient.h>
#include <WiFiClientSecure.h>
#include <Arduino_JSON.h>
#include "servocontrol.h"
#include "ContactFree_Temp_Test_header_v.h"
#include "air_sensing.h"
#include "gas_sensing.h"
#include "ultra_sensing.h"
#include "definitions_pin.h"

//Domain name with URL path or IP address with path
const char* PostserverName = "https://ssokdam.com/api/embedded/send";                  //tb_embedded
const char* GetserverName = "https://ssokdam.com/api/embedded/receive?embId=1";        //tb_embedded - user_id & emb_qr
const char* ReturnserverName = "https://ssokdam.com/api/use";                          //tb_use

int inputStatus= 0; //0 : 투입 X, 1 : 투입 O - CDS & Neopixel 이용
int ciga_check =0; // 0 : 담배 X, 1 : 담배 O - ContactFree_Temp & Airqulity & Gas
char posting[128];
String userId;
String information;
String informationsArr[2];

int cds_critria;

void useCheckreturn(int ciga_check){ //0이면 담배아님 //1이면 담배임
  WiFiClientSecure client;
  HTTPClient http;
  client.setInsecure();
  http.begin(client, ReturnserverName); //use쪽으로 리턴한다.  
  http.addHeader("Content-Type", "application/json");
  char input[] = "{\"embId\":1,\"userId\": %s,\"useCheck\": %s }";
      
  if(ciga_check ==0){
     sprintf(posting, input,  userId,"\"N\""); //담배 아님
  }
  else if(ciga_check == 1){
     sprintf(posting, input, userId,"\"Y\""); //담배 임
  }
      
  int httpResponseCode = http.POST(posting);
  Serial.println(posting);
  Serial.print("HTTP Response code: ");
  Serial.println(httpResponseCode);
  http.end();       // Free resources
}

String httpGETRequest(const char* GetserverName) {
  HTTPClient http;
  http.begin(GetserverName);
  int httpResponseCode = http.GET();
  String payload = "{}"; 
  if (httpResponseCode>0) {
    Serial.print("HTTP Response code: ");
    Serial.println(httpResponseCode);
    payload = http.getString();
  }
  else {
    Serial.print("Error code: ");
    Serial.println(httpResponseCode);
  }
  http.end();
  return payload;
}

void Get(){
  information = httpGETRequest(GetserverName);
  JSONVar myObject = JSON.parse(information);
  // JSON.typeof(jsonVar) can be used to get the type of the var
  if (JSON.typeof(myObject) == "undefined") {
    Serial.println("Parsing input failed!");
    return;
    }
  //Serial.print("JSON object = ");
  //Serial.println(myObject);
  // myObject.keys() can be used to get an array of all the keys in the object
  
  JSONVar keys = myObject.keys();
  for (int i = 0; i < keys.length(); i++) {
    JSONVar value = myObject[keys[i]];
    JSONVar Qrc = "Y"; //for check
    JSONVar UC = "userId";
    Serial.print(keys[i]);
    Serial.print(" = ");
    Serial.println(value);
    
    if( keys[i] == UC){                   //사용자 아이디를 받아온다
     userId = JSON.stringify(value);      //test
    }
    if (value == Qrc){                    //y되는 순간 뚜껑이 열린다.
      inputStatus = 0;                    //넣었는지 안넣었는지 flag 초기화 
      ciga_check = 0;

      neopixel_on();       //NeoPixel on
      iris_open();        //iris open

      /* recognition - CDS */
      unsigned long end_time = millis();
      unsigned long cdsDelay = 4000;
      //cds_critria = cds_avg();
      while((millis() - end_time) < cdsDelay){
        if(analogRead(CDS_SENSOR_PIN)> 1500){
          Serial.println("inputStatus = 1");
          inputStatus = 1;
          break;
        }
      }
      delay(1000);
      neopixel_off();
      delay(1500);
      slider1_close();
      iris_close();
      
      /* Judge */
      if(inputStatus != 1) Serial.println("inputStatus = 0 & Post");
      if(inputStatus == 1){
        unsigned long finish_time = millis();
        unsigned long judgeDelay = 5*1000;
        int temp_flag = 0;
        int gas_flag = 0;
        int air_flag = 0;
        while(((millis() - finish_time))<judgeDelay && temp_flag == 0){
          if(temp_check() > 40){
            temp_flag = 1;
            Serial.print("temp : ");
            Serial.println(temp_check());
          }
          if(gas_check() >700){
            gas_flag = 1;
            Serial.print("gas : ");
            Serial.println(gas_check());
          }
          if(air_check() >8){
            air_flag = 1;
            Serial.print("air : ");
            Serial.println(air_check());
          }
          Serial.print("temp : ");
          Serial.println(temp_check());
          Serial.print("gas : ");
          Serial.println(gas_check());
          Serial.print("air : ");
          Serial.println(air_check());    
        }

        if(temp_flag == 1) ciga_check = 1;
        if(gas_flag ==1 || air_flag ==1) ciga_check = 1;

        slider1_finish();

        /*Move Trash Bin or CiGa Bin*/
        if(ciga_check ==1){
          Serial.println("ciga_check = 1");
          slider2_cig();
          smash();
        }
        if(ciga_check !=1){
          Serial.println("ciga_check = 0");
          slider2_trash();
        }
      }
      Serial.print("Trash Bin distance : ");
      Serial.println(Trash_Check());
      Serial.print("Cig Bin distance : ");
      Serial.print(Cig_Check());
      }
  }
}

void Post(){ //1시간마다 정보전달하는 함수 
  WiFiClientSecure client;
  HTTPClient http;
  client.setInsecure();
  
  //Sensing Data
  long Trash_val = Trash_Check() / 18 * 100;
  long Cig_val; = Cig_Check() / 18 * 100;
  float battery = ((analogRead(15)+ 100) * 12.56)/557 - 0.1;
  double MyHome_Lat = 35.18380150;
  double MyHome_Lng = 126.79374240;

  http.begin(client, PostserverName);
  http.addHeader("Content-Type", "application/json");
  char input[] = "{\"embId\":1,\"userId\":\"admin\",\"embFullTra\": %d ,\"embFullCig\":%d,\"embLat\":\"%lf\",\"embLng\":\"%lf\",\"embBat\":%d,\"embCnt\":0,\"embSta\":\"Y\"}";
  sprintf(posting, input, Trash_val, Cig_val,MyHome_Lat,MyHome_Lng,battery);
  int httpResponseCode = http.POST(posting);
  Serial.println(posting);
  Serial.print("HTTP Response code: ");
  Serial.println(httpResponseCode);
  http.end();           // Free resources
}
