#include <ESP32_Servo.h>
#include <Adafruit_NeoPixel.h>
#include "definitions_pin.h"

//Servo
Servo servo1;
Servo servo2;
Servo servo3;
Servo servo4;

//NeoPixel
Adafruit_NeoPixel  pixel(numLeds,ledPin,NEO_GRBW + NEO_KHZ800 );
Adafruit_NeoPixel  ring(RingLeds,ledRingPin,NEO_GRB + NEO_KHZ800);  

void iris_close() {
  for(int posDegrees = 0; posDegrees <= 150; posDegrees++) {
    servo2.write(posDegrees); // 모터의 각도를 설정합니다.
    servo1.write(posDegrees);
    delay(10);
    }
    Serial.println("QR recognition OPEN - Iris Mech");
}

void iris_open() {
  for(int posDegrees = 150; posDegrees >= 0; posDegrees--) {
    servo2.write(posDegrees); // 모터의 각도를 설정합니다.
    servo1.write(posDegrees);
    delay(10);
    }
    Serial.println("Object is Detected Close - Iris Mech");
}

void slider1_open(){
    for(int posDegrees = 90; posDegrees >= 35; posDegrees--) {
        servo3.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(10);
    }
    Serial.println("Slider1 Open");
}

void slider1_close(){
  for(int posDegrees = 35; posDegrees <= 90; posDegrees++) {
        servo3.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(10);
    }
    Serial.println("Slider1 Close");
}

void slider1_finish(){
    for(int posDegrees = 90; posDegrees >= 35; posDegrees--) {
        servo3.write(posDegrees); // 모터의 각도를 설정합니다.
        delay(10);
    }
    Serial.println("Judgement is Finished. - Slider1 Open");
}

void slider2_cig(){
    for(int posDegrees = 75; posDegrees >= 15; posDegrees--) {
      servo4.write(posDegrees); // 모터의 각도를 설정합니다.
      delay(15);
    }
    for(int posDegrees = 15; posDegrees <= 75; posDegrees++) {
      servo4.write(posDegrees); // 모터의 각도를 설정합니다.
      delay(15);
    }
    Serial.println("Goto Smash - Slider2 Right");
}

void slider2_trash(){
  for(int posDegrees = 75; posDegrees <= 135; posDegrees++) {
    servo4.write(posDegrees); // 모터의 각도를 설정합니다.
    delay(15);
  }
  delay(500);
  for(int posDegrees = 135; posDegrees >= 75; posDegrees--) {
    servo4.write(posDegrees); // 모터의 각도를 설정합니다.
    delay(15);
  }
  Serial.println("Goto Trash bin - Slider2 Ledft");
}

void smash(){
  digitalWrite(relay_1,HIGH);
  delay(4000);
  digitalWrite(relay_1,LOW);
  delay(4000);
}

void neopixel_on(){
  //Neopixel init
  pixel.begin();
  pixel.show();
  pixel.setBrightness(255);
  
  //Neopixel white color
  pixel.setPixelColor(0,255,255,255,255);
  pixel.show();
}

void ringpixel_on(){
  ring.clear();
  ring.begin();
  ring.show();
  ring.setBrightness(255);

  for(int i=0;i<12;i++){
    ring.setPixelColor(i,255,255,255);
    ring.show();
  }
}

void neopixel_off(){
  //Neopixel init
  pixel.begin();
  pixel.show();
  pixel.setBrightness(255);
  
  //Neopixel white color
  pixel.setPixelColor(0,0,0,0,0);
  pixel.show();
}

int cds(){
  Serial.println(analogRead(CDS_SENSOR_PIN));
  return analogRead(CDS_SENSOR_PIN);
}

int cds_avg(){
  int cdsAvg = 0;
  for(int i=0;i<i<50;i++){
    cdsAvg += analogRead(CDS_SENSOR_PIN);
  }
  cdsAvg = cdsAvg/50;
  return cdsAvg;
}
